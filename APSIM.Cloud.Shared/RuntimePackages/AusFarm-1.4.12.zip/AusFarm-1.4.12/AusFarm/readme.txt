
These XML files have a small modification to the base APSIM ones.

This is to accommodate for the AusFarm Translator component.

<!--      <x_removeBiomPheno description="fraction of above ground biomass removed">0.0  0.1   0.4  0.5  1.0</x_removeBiomPheno> -->
<!--      <y_removeFractPheno description="fraction of above ground thermal time removed">0.0  0.08  0.4  0.5  1.0</y_removeFractPheno> -->
<!--      Using the AusFarm Translator component which considers the phenology during removal -->
      <x_removeBiomPheno description="fraction of above ground biomass removed">0.0  1.0</x_removeBiomPheno>
      <y_removeFractPheno description="fraction of above ground thermal time removed">0.0  0.0</y_removeFractPheno>
